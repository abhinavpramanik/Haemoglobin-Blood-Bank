package com.dev334.blood.ui.home;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.dev334.blood.R;

public class UserFeedback extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_feedback);
    }
}